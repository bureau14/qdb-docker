quasardb
========

quasardb is a distributed, high-performance, time series database designed from the ground up for the most demanding environments.

- [Official website](https://www.quasardb.net/)
- [User documentation](https://doc.quasardb.net/)

Contact
========

quasardb
24, rue Feydeau
75002 Paris
France

www : https://www.quasardb.net/
e-mail : contact@quasardb.net
bug reports : bug@quasardb.net
tel: +33 (0)1 55 34 92 30
